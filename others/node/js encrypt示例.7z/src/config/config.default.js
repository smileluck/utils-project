const dotenv = require("dotenv");
dotenv.config();

//console.log(process.env.PORT); 

module.exports = process.env;
